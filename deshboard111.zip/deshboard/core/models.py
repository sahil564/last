from django.db import models
from django.contrib.auth.models import User

# Create your models here.


# import the standard Django Model
# from built-in library
from django.db import models


# class Customer(models.Model):
#     user=models.OneToOneField(User,null=True,on_delete=models.CASCADE)
#     name=models.CharField(max_length=200,null=True)
    
    # def __str__(self):
    #     return self.name


# declare a new model with a name "GeeksModel"
class Machine(models.Model):
        # fields of the model
    customer = models.ForeignKey(User, null=True, on_delete= models.SET_NULL)
    username = models.CharField(max_length = 200)
    email = models.EmailField(max_length = 200)
    machine_ID = models.CharField(max_length = 200)
    machine_IDC = models.CharField(max_length = 200)
    number= models.IntegerField(blank=True, null=True)
    sensorname = models.CharField(max_length = 200)
  
    
    
 
        # renames the instances of the model
        # with their title name
    def __str__(self):
        return self.machine_ID
    
    
class Fault_occur(models.Model):
        # fields of the model
    customer = models.ForeignKey(User, null=True, on_delete= models.SET_NULL)
    machine_ID = models.ForeignKey(Machine, null=True, on_delete= models.SET_NULL)
    email = models.EmailField(max_length = 200)
    messages=models.CharField(max_length = 200)
    reason=models.CharField(max_length = 200)
    fault_data = models.DateTimeField(auto_now_add=True,null=True)
    # machine_ID=str(machine_ID)
   # renames the instances of the model
        # with their title name
    def __str__(self):
        return str(self.machine_ID)
    
    
    
    
class Fault_future(models.Model):
        # fields of the model
    customer = models.ForeignKey(User, null=True, on_delete= models.SET_NULL)
    machine_ID = models.ForeignKey(Machine, null=True, on_delete= models.SET_NULL)
    email = models.EmailField(max_length = 200)
    messages=models.CharField(max_length = 200)
    reason=models.CharField(max_length = 200)
    fault_data = models.CharField(max_length = 200)
    # machine_ID=str(machine_ID)
   # renames the instances of the model
        # with their title name
    def __str__(self):
        return str(self.machine_ID)
    
    
    
    
class Email_user(models.Model):
    # fields of the model
    customer = models.ForeignKey(User, null=True, on_delete= models.SET_NULL)
    machine_ID = models.ForeignKey(Machine, null=True, on_delete= models.SET_NULL)
    email = models.EmailField(max_length = 200)
    messages=models.CharField(max_length = 200)
    fault_data = models.DateTimeField(auto_now_add=True,null=True)
    # machine_ID=str(machine_ID)
   # renames the instances of the model
        # with their title name
    def __str__(self):
        return self.email
















# class machines(models.Model):
# 	username = models.CharField(max_length=200, null=True)
# 	machine_name = models.CharField(max_length=200, null=True)
#     machine_name = models.CharField(max_length=200, null=True)
#     machine_name = models.CharField(max_length=200, null=True)
# 	email = models.CharField(max_length=200, null=True)
# 	date_created = models.DateTimeField(auto_now_add=True, null=True)

# 	def __str__(self):
# 		return self.name


# class Tag(models.Model):
# 	name = models.CharField(max_length=200, null=True)

# 	def __str__(self):
# 		return self.name

# class Product(models.Model):
# 	CATEGORY = (
# 			('Indoor', 'Indoor'),
# 			('Out Door', 'Out Door'),
# 			) 

# 	name = models.CharField(max_length=200, null=True)
# 	price = models.FloatField(null=True)
# 	category = models.CharField(max_length=200, null=True, choices=CATEGORY)
# 	description = models.CharField(max_length=200, null=True, blank=True)
# 	date_created = models.DateTimeField(auto_now_add=True, null=True)
# 	tags = models.ManyToManyField(Tag)

# 	def __str__(self):
# 		return self.name

# class Order(models.Model):
# 	STATUS = (
# 			('Pending', 'Pending'),
# 			('Out for delivery', 'Out for delivery'),
# 			('Delivered', 'Delivered'),
# 			)

# 	customer = models.ForeignKey(Customer, null=True, on_delete= models.SET_NULL)
# 	product = models.ForeignKey(Product, null=True, on_delete= models.SET_NULL)
# 	date_created = models.DateTimeField(auto_now_add=True, null=True)
# 	status = models.CharField(max_length=200, null=True, choices=STATUS)
# 	note = models.CharField(max_length=1000, null=True)

	# def __str__(self):
	# 	return self.product.name



	
