from django.urls import path
from .consumers import GraphConsumer,GraphConsumer1,GraphConsumer2,GraphConsumer3
from .consumers import GraphConsumer4

ws_urlpatterns = [
    path("ws/graph/",GraphConsumer.as_asgi()),
    path("ws/graph1/",GraphConsumer1.as_asgi()),
    path("ws/graph2/",GraphConsumer2.as_asgi()),
    path("ws/graph3/",GraphConsumer3.as_asgi()),
    path("ws/graph4/",GraphConsumer4.as_asgi()),
    
]